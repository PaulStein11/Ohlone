/*******************************************************

 * Program Name: Week 1 In Class Assignment

 * Author: Paul Barrionuevo

 * Date: 8/30/2024

 * Description: Smart Home combining all the sensor given from a house
 * Pending to apply inheritance, having the option to skip it as mentioned,
 * and making the Smart Home to have a synchronous retrieval of status
 * of all the sensor defined

 *******************************************************/

#include "smartHome.h"

int main() {

	SmartHome smartHome;

	return 0;
}