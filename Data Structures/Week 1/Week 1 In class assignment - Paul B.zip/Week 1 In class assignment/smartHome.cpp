#include "smartHome.h"

#include "SmartHome.h"

SmartHome::SmartHome() {}

string SmartHome::setSmartHome() {
    return "Reading smart devices...";
   /*
    appliances.setStatus();
    energySystem.setStatus();
    garageDoor.setStatus();
    mainAlarm.setAlarm();
    glassAlarm.setAlarm();
    lights.setLights();
    locker.setLocker();
    motionSensor.setStatus();
    phoneAlerts.setNotifications();
    thermostat.setStatus();
   */ 
}
